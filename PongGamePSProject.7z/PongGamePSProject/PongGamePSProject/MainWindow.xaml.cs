﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PongGamePSProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        PongGame application;
        DispatcherTimer timer;

        public MainWindow()
        {
            InitializeComponent();
            application = new PongGame(this.Height,this.Width);

            timer = new DispatcherTimer();
    
            timer.Interval = new TimeSpan(0, 0, 0, 0, 25);  
            timer.Tick += timer_Timeout;

        }
        void timer_Timeout(object sender, EventArgs e)
        {
            application.update_position();  

            int count = 0;
            for (int i = 0; i < mycanvas.Children.Count; i++)
            {
                if (mycanvas.Children[i] is Shape)
                {
                    count++;
                }
            }
            mycanvas.Children.RemoveRange(0, count);
            updateDisplay();

        }
        
        private void Window_KeyDown_1(object sender, KeyEventArgs e)
        {
            application.update_key(e, true);
        }

        private void Window_KeyUp_1(object sender, KeyEventArgs e)
        {   
            application.update_key(e, false);
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            updateDisplay();
            timer.Start();
        }
        private void updateDisplay()
        {
            List<Shape> list = application.getAllShapes();
            foreach (Shape rec in list)
            {
                mycanvas.Children.Add(rec);
            }

        }
    }
}
