﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PongGamePSProject
{
    class Player
    {
        public Rectangle rect;
        public bool mov_up = false;
        public bool mov_down = false;
        Key upKey;
        Key downKey;
        double windowHeight;
        int step = 10;
        public double x;
        public double y;

        public Player(double windowHeight, Key upKey, Key downKey, int x)
        {
            rect = new Rectangle();
            this.windowHeight = windowHeight;
            this.upKey = upKey;
            this.downKey = downKey;
            this.x = x;     
            this.y = 0;

        }
        public void reset_key()
        {
            this.mov_down = false;
            this.mov_up = false;
        }
        public void update_pos()
        {
            if (mov_up && mov_down)
            {
                return;
            }
            else if (mov_up)
            {
                //move up only if possible
                if (this.y - step >= 0)
                {
                    y -= step;
                }
            }
            else if (mov_down)
            {
                if ((y + rect.Height + step )<= 500)
                {
                    //move down only if possible
                    y += step;
                }
            }
        }

        public void update_key(Key key, bool down)
        {
            if ( upKey.Equals(key))
            {
                mov_up = down;
            }
            else if (key == downKey)
            {
                mov_down = down;
            }
        }
    }
}
