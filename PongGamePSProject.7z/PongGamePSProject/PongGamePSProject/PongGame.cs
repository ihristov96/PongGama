﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Controls;
namespace PongGamePSProject
{
    class PongGame
    {
        private Player player1;
        private Player player2;
        private Ball ball;
        public int player1Score = 0;
        public int player2Score = 0;
        public int stopGame = 0;
        public PongGame(double windowHeight, double windowWidth)
        {
            player1 = new Player(
                windowHeight,
                Key.W,
                Key.S,
                0);
            player2 = new Player(
                windowHeight,
                Key.Up,
                Key.Down,
                780);
            ball = new Ball(
                windowHeight,
                windowWidth);
        }

        public void update_position()
        {
            stopGame = ball.update_pos(player1, player2);
            if (stopGame > 0)
            {
                if (stopGame == 1)
                {
                        player1Score++;
                        MessageBox.Show("Blue: " + player1Score + "\n" + "Red: " + player2Score);
                        ball.reset();
                        player1.reset_key();
                        player2.reset_key();

                }
                else if (stopGame == 2)
                {
                    player2Score++;

                    MessageBox.Show("Blue: " + player1Score + "\n" + "Red: " + player2Score);
                    ball.reset();
                    player1.reset_key();
                    player2.reset_key();
                }
                return;
            }
            player1.update_pos();
            player2.update_pos();
        }

        public void resetBall()
        {
            ball.reset(); 
        }

        public void update_key(KeyEventArgs e, bool down)
        {
           player1.update_key(e.Key, down);
           player2.update_key(e.Key, down);      
        }

        public List<Shape> getAllShapes()
        {
            List<Shape> list = new List<Shape>();
            Rectangle rec1 = player1.rect;


            rec1.Width = 20;
            rec1.Height = 100;
            rec1.Fill = Brushes.Blue;

            Canvas.SetLeft(rec1, player1.x);
            Canvas.SetTop(rec1, player1.y);

            Rectangle rec2 = player2.rect;


            rec2.Width = 20;
            rec2.Height = 100;
            rec2.Fill = Brushes.Red;

            Canvas.SetLeft(rec2, player2.x);
            Canvas.SetTop(rec2, player2.y);

            Ellipse rec3 = ball.r;
            
            rec3.Width = 20;
            rec3.Height = 20;
            rec3.Fill = Brushes.White;

            Canvas.SetLeft(rec3, ball.x);
            Canvas.SetTop(rec3, ball.y);

            list.Add(rec1);
            list.Add(rec2);
            list.Add(rec3);

            return list;
        }

        
    }
}
