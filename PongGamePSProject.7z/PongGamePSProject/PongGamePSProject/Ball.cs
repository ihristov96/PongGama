﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Shapes;

namespace PongGamePSProject
{
    class Ball
    {
        private Random rand;
        public Ellipse r;
        int dx;
        int dy;
        public double x;
        public double y;
        double windowHeight;
        double windowWidth;
        public Ball(double windowHeight, double windowWidth)
        {
            this.r = new Ellipse();
            this.x = 0;
            this.y = 0;
            this.windowHeight = windowHeight;
            this.windowWidth = windowWidth;
            rand = new Random();
            reset();
        }

        public void reset()
        {
            this.x = windowWidth / 2;
            this.y = windowHeight / 2;
            dx = rand.Next(5, 7);
            dy = rand.Next(5, 7);             
        }

        public int update_pos(Player p1, Player p2)
        {
            if (this.x <= 0)
            {
                return 2;
            }
            else if (this.x  + r.Width >= 800)
            {
                return 1;
            }
            if( y <= 0 || y >= 480)
            {
                dy = -dy;
            }
         
            if ((x <= (p1.x + 20)) && 
               (y > p1.y && y < (p1.y+100) ))
            {
                bounceWith(p1);
            }
            
            if (x >= (p2.x - 20) &&
                (y > p2.y && y < (p2.y + 100)))
            {
                bounceWith(p2);

            }
            this.x += dx;
            this.y += dy;
            return 0;
           
        }

        private void bounceWith(Player p)
        {
            dx = -dx;
            
            if (dx > 0 && x + dx < p.x+20)
            {
                // If bounce with top or bottom of player1
                dx = -Math.Abs(dx);
                dy = -dy;
            }
            else if (dx < 0 && (x+20) + dx > p.x+20)
            {
                // If bounce with top or bottom of player2
                dx = Math.Abs(dx);
                dy = -dy;
            }
            else
            {
                if (p.mov_down && !p.mov_up)
                {
                    if (dy > 0)
                    {
                        // Player down, ball down
                        dy += 1;
                    }
                    else
                    {
                        // Player down, ball up
                        dy = -dy;
                    }
                }
                else if (p.mov_up && !p.mov_down)
                {
                    if (dy > 0)
                    {
                        // Player up, ball down
                        dy = -dy;
                    }
                    else
                    {
                        // Player up, ball up
                        dy += -1;
                    }
                }
            }
        }
    }
}
